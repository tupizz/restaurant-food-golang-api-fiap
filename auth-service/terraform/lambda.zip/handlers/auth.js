"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerUser = registerUser;
const utils_1 = require("../utils");
async function registerUser(event) {
    try {
        // Parse the request body
        const body = event.body ? JSON.parse(event.body) : {};
        return (0, utils_1.createResponse)(201, {
            success: true,
            data: body,
        });
    }
    catch (error) {
        console.error("Registration error:", error);
        return (0, utils_1.createResponse)(error.statusCode || 500, {
            error: error.code || "RegistrationError",
            message: error.message || "An error occurred during registration",
        });
    }
}
//# sourceMappingURL=auth.js.map