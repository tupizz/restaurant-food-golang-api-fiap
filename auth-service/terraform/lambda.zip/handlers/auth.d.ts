import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare function registerUser(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
