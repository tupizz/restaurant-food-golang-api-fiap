import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare function index(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
