"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.index = index;
const utils_1 = require("../utils");
async function index(event) {
    try {
        return (0, utils_1.createResponse)(200, {
            success: true,
            data: "Hello World",
        });
    }
    catch (error) {
        console.error("Index error:", error);
        return (0, utils_1.createResponse)(error.statusCode || 500, {
            error: error.code || "IndexError",
            message: error.message || "An error occurred during index",
        });
    }
}
//# sourceMappingURL=index.js.map