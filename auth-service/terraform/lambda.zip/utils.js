"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createResponse = createResponse;
// Helper function to create a response
function createResponse(statusCode, body) {
    return {
        statusCode,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*", // This should be configured based on your CORS needs
            "Access-Control-Allow-Credentials": "true",
        },
        body: JSON.stringify(body),
        isBase64Encoded: false,
    };
}
//# sourceMappingURL=utils.js.map