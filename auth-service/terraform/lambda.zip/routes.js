"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routes = void 0;
exports.generateTerraformRouteKeys = generateTerraformRouteKeys;
// Import your handler functions
const handlers_1 = require("./handlers");
const auth_1 = require("./handlers/auth");
// Define your routes
exports.routes = [
    {
        method: "POST",
        path: "/auth/register",
        handler: auth_1.registerUser,
        description: "Register a new user",
    },
    {
        method: "GET",
        path: "/",
        handler: handlers_1.index,
        description: "Index route",
    },
];
// Export a function to generate Terraform-compatible route keys
function generateTerraformRouteKeys() {
    return exports.routes.map((route) => `${route.method} ${route.path}`);
}
//# sourceMappingURL=routes.js.map