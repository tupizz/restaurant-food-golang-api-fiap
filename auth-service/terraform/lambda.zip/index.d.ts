import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare function handler(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
