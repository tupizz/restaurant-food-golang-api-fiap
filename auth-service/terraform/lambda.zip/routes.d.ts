import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export type RouteHandler = (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export interface RouteConfig {
    method: string;
    path: string;
    handler: RouteHandler;
    description?: string;
}
export declare const routes: RouteConfig[];
export declare function generateTerraformRouteKeys(): string[];
