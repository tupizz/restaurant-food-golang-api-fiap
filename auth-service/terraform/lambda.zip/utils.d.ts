import { ApiResponse, ErrorResponse, SuccessResponse } from "./types";
export declare function createResponse<T>(statusCode: number, body: SuccessResponse<T> | ErrorResponse): ApiResponse;
